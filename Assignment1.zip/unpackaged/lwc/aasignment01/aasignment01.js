import { LightningElement, track } from 'lwc';
import {wire} from 'lwc';
import getAccounts from '@salesforce/apex/Assignment1Class.getAccounts';
export default class Aasignment01 extends LightningElement {
    
   @track myaccountdetails;
@track searchTerm='e';
@track nos=10;
@track valueChange;
@track resultData;
//@track filterTerm;
    constructor(){
        super();
        console.log('In the constructor');
    }
    async handleClick1(){
        console.log('inside handleclick1');
        let inputData1=this.template.querySelectorAll("lightning-input");
        inputData1.forEach(function(element){
            if(element.name=="input1"){
                
                this.searchTerm=element.value;
            }
            if(element.name=="input3"){
                if(element.value==undefined || element.value==null || element.value==''){
                }else{
                    this.searchTerm=element.value;
                }  
               
            }
            else if(element.name=="input2"){
                console.log('input2 value '+element.value);
                if(element.value==undefined || element.value==null || element.value==''){
                    this.nos=10;
                }else {
                    this.nos=element.value;
                }
            }
        },this);
        console.log(this.searchTerm+' value '+ this.nos);
        let result=await getAccounts({Name:this.searchTerm,Nos:this.nos});
        console.log(result);
        this.myaccountdetails=result;
        this.resultData=result;
    }    

    
   onChangeHandle(event){
       if(event.target.value!=null){
          console.log('value added');
       this.searchTerm=event.target.value;
       this.valueChange=event.target.value;
       console.log('value added'+event.target.value);
       

       }
       
   }
   handleClick2(){
       console.log(this.myaccountdetails);
        let copy=[...this.resultData];
        this.myaccountdetails=copy.filter(item=>{
          return  item.Name.includes(this.valueChange);
        });
        


   }
  
 }